#ifndef  __MAIN_H_
#define  __MAIN_H_
#include<msp430x54x.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "PIN_DEF.H"
#include "LD3320.h"

extern unsigned char  nAsrStatus;
extern unsigned char  nAsrRes;
#endif