
#include "config.h"


#ifdef HARD_PARA_PORT

		#define LD_INDEX_PORT		(*((volatile unsigned char xdata*)(0x8100))) 
		#define LD_DATA_PORT		(*((volatile unsigned char xdata*)(0x8000)))
 
		
		//�������� MCU��A8 ���ӵ� LDоƬ��AD
		//         MCU��A14 ���ӵ� LDоƬ��CSB
		//         MCU��RD��WR ���� LDоƬ��RD��WR (xdata ��дʱ�Զ��������ź�)
		//
		//0x8100�Ķ�������10000001 00000000		CSB=0 AD=1
		//                 ^     ^
		//0x8000�Ķ�������10000000 00000000		CSB=0 AD=0
		//                 ^     ^
		
		void LD_WriteReg( unsigned char address, unsigned char dataout )
		{
			LD_INDEX_PORT  = address;         
			LD_DATA_PORT = dataout;          
		}
		
		unsigned char LD_ReadReg( unsigned char address )
		{
			LD_INDEX_PORT = address;         
			return (unsigned char)LD_DATA_PORT;     
		}
#endif  

/*..........................................�޸�end....................................................*/
//����ģ�Ⲣ�з�ʽ��д
#ifdef SOFT_PARA_PORT

		#define DELAY_NOP	NOP();NOP();NOP();NOP();NOP();  

#define LD_WR_CLR PORTB &= ~(1 << PB3)  
#define LD_WR_SET PORTB |= (1 << PB3)

#define LD_RD_CLR PORTB &= ~(1 << PB4)  
#define LD_RD_SET PORTB |= (1 << PB4)

#define LD_CS_CLR PORTB &= ~(1 << PB5)  
#define LD_CS_SET PORTB |= (1 << PB5)

#define LD_A0_CLR PORTB &= ~(1 << PB6)  
#define LD_A0_SET PORTB |= (1 << PB6)


	void LD_WriteReg( unsigned char address, unsigned char dataout )
		{
			PORTA = address;
			LD_A0_SET;
			LD_CS_CLR;
			LD_WR_CLR;
			DELAY_NOP;
		
			LD_WR_SET;
			LD_CS_SET;
			DELAY_NOP;
		
			PORTA = dataout;
			LD_A0_CLR;
			LD_CS_CLR;
			LD_WR_CLR;
			DELAY_NOP;
		
			LD_WR_SET;
			LD_CS_SET;
			DELAY_NOP;
		}
		
		unsigned char LD_ReadReg( unsigned char address )
		{
			unsigned char datain;
		
			PORTA = address;
			LD_A0_SET;
			LD_CS_CLR;
			LD_WR_CLR;
			DELAY_NOP;
		
			LD_WR_SET;
			LD_CS_SET;
			DELAY_NOP;
		
			LD_A0_CLR;
			LD_CS_CLR;
			LD_RD_CLR;
			DELAY_NOP;

			datain = PORTA;
			LD_RD_SET;
			LD_CS_SET;
			DELAY_NOP;
		
			return datain;
		}
#endif
/*..........................................�޸�end....................................................*/

////����ģ��SPI��ʽ��д
//#ifdef SOFT_SPI_PORT
//		#define DELAY_NOP	NOP()();NOP()();NOP();
//		
//		sbit SCS=P2^1;    //оƬƬѡ�ź�
//		sbit SDCK=P0^2;   //SPI ʱ���ź�
//		sbit SDI=P0^0;    //SPI ��������
//		sbit SDO=P0^1;    //SPI �������
//		sbit SPIS=P3^5;   //SPIģʽ���ã�����Ч��
//
//		void LD_WriteReg(unsigned char address,unsigned char dataout)
//		{
//			unsigned char i = 0;
//			unsigned char command=0x04;
//			SPIS =0;
//			SCS = 0;
//			DELAY_NOP;
//		
//			//write command
//			for (i=0;i < 8; i++)
//			{
//				if ((command & 0x80) == 0x80) 
//					SDI = 1;
//				else
//					SDI = 0;
//				
//				DELAY_NOP;
//				SDCK = 0;
//				command = (command << 1);  
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//			//write address
//			for (i=0;i < 8; i++)
//			{
//				if ((address & 0x80) == 0x80) 
//					SDI = 1;
//				else
//					SDI = 0;
//				DELAY_NOP;
//				SDCK = 0;
//				address = (address << 1); 
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//			//write data
//			for (i=0;i < 8; i++)
//			{
//				if ((dataout & 0x80) == 0x80) 
//					SDI = 1;
//				else
//					SDI = 0;
//				DELAY_NOP;
//				SDCK = 0;
//				dataout = (dataout << 1); 
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//			DELAY_NOP;
//			SCS = 1;
//		}
//
//		unsigned char LD_ReadReg(unsigned char address)
//		{
//			unsigned char i = 0; 
//			unsigned char datain =0 ;
//			unsigned char temp = 0; 
//			unsigned char command=0x05;
//			SPIS =0;
//			SCS = 0;
//			DELAY_NOP;
//		
//			//write command
//			for (i=0;i < 8; i++)
//			{
//				if ((command & 0x80) == 0x80) 
//					SDI = 1;
//				else
//					SDI = 0;
//				DELAY_NOP;
//				SDCK = 0;
//				command = (command << 1);  
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//
//			//write address
//			for (i=0;i < 8; i++)
//			{
//				if ((address & 0x80) == 0x80) 
//					SDI = 1;
//				else
//					SDI = 0;
//				DELAY_NOP;
//				SDCK = 0;
//				address = (address << 1); 
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//			DELAY_NOP;
//
//			//Read data
//			for (i=0;i < 8; i++)
//			{
//				datain = (datain << 1);
//				temp = SDO;
//				DELAY_NOP;
//				SDCK = 0;  
//				if (temp == 1)  
//					datain |= 0x01; 
//				DELAY_NOP;
//				SDCK = 1;  
//			}
//		
//			DELAY_NOP;
//			SCS = 1;
//			return datain;
//		}
//
//#endif
